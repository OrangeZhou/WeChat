import * as echarts from '../../ec-canvas/echarts.common.min';

const app = getApp();
// var sports_data = wx.getStorageSync('sports_data');
// var data = sports_data.data;
function setOption(chart) {
  let data =wx.getStorageSync('sports_data').data;
  for(let i in data){
    if(data[i]>300){
      data[i]=300
    }else{
      data[i]=data[i]
    }
  }
  const option = {
    color: ["#CA151D"],
    backgroundColor: '#000',
    tooltip: {
      show: true,
      trigger: 'item',
      axisPoninter: {
        axis: 'x',
        type: 'line',
        lineStyle: {
          color: '#fff'
        }
      }
    },
    grid: {

    },
    xAxis: [
      {
        splitLine: {
          show: false
        },
        axisLine: {
          show: false
        },
        axisTick: {
          show: false
        },
        axisLabel: {
          show: true,
          textStyle: {
            color: '#fff'
          },
          interval: 0
        },
        data: wx.getStorageSync('sports_data').date,
        position: 'bottom'
      },
    ],
    yAxis: [
      {
        show: false
      }
    ],
    visualMap: {
      show: false,
      max: 100,
      inRange: {
        symbolSize: [20, 70]
      }
    },
    series: [{
      type: 'scatter',
      name: 'aaaa',
      data:data,
      symbolSize: function (data) {
        return Math.sqrt(data) / 0.3;
      },
      labelLine: {
        normal: {
          show: true
        }
      },
    },
    ],
    animationDelay: function (idx) {
      return idx * 50;
    },
    animationEasing: 'elasticOut'
  };
  chart.setOption(option);
}
Page({
  onShareAppMessage: function (res) {
    return {
      title: 'ECharts 可以在微信小程序中使用啦！',
      path: '/pages/index/index',
      success: function () { },
      fail: function () { }
    }
  },
  data: {
    ec: {
      // 将 lazyLoad 设为 true 后，需要手动初始化图表
      lazyLoad: true
    },
    dataList: ''
  },
  // 点击按钮后初始化图表
  init: function () {
    this.ecComponent.init((canvas, width, height) => {
      // 获取组件的 canvas、width、height 后的回调函数
      // 在这里初始化图表
      const chart = echarts.init(canvas, null, {
        width: width,
        height: height
      });
      setOption(chart);
      // 将图表实例绑定到 this 上，可以在其他成员函数（如 dispose）中访问
      this.chart = chart;
      this.setData({
        ec:{
          isLoaded: true,
        }
      });
      // 注意这里一定要返回 chart 实例，否则会影响事件处理等
      return chart;
    });
  },
  onLoad:function(options){
    var that = this;
    wx.showNavigationBarLoading();
    wx.request({
      url: app.data.url + '/day_show',
      header: app.getHeader(),
      method: "POST",
      data: {
        day: options.mon
      },
      success: function (res) {
        // console.log(res.data)
        if (res.data.courses) {
          var time = res.data.courses;
          var qiu = res.data.date;
          var qiu_data = {};
          qiu_data.date = [];
          qiu_data.data = [];
          for (let i in time) {
            if (time[i].inter_at) {
              time[i].inter_at = time[i].inter_at.substring(11, 19);
            }
            if (time[i].out_at) {
              time[i].out_at = time[i].out_at.substring(11, 19);
            }
          }
          if (res.data.record) {
            if (res.data.record.inter_at) {
              res.data.record.inter_at = res.data.record.inter_at.substring(11, 19);
            }
            if (res.data.record.out_at) {
              res.data.record.out_at = res.data.record.out_at.substring(11, 19);
            }
          }
        }
        for (let i in qiu) {
          if (qiu[i].long == 0) {
            qiu[i].long = 0
          }
          if (qiu[i].day.date.substring(5, 10).replace('-', '.')[0] == '0') {
            qiu_data.date.push(qiu[i].day.date.substring(5, 10).replace('-', '.').substr(1));

          }else{
            qiu_data.date.push(qiu[i].day.date.substring(5, 10).replace('-', '.'));
          }
          qiu_data.data.push(qiu[i].long)
        }
        wx.setStorageSync('sports_data', qiu_data);
        // console.log(wx.getStorageSync('sports_data'))
        that.init()
        that.setData({
          dataList: res.data,
          date: options.mon,
          sporst_time: res.data.date[6].long,
        })
      },
    })
    wx.hideNavigationBarLoading()
    
  },
  onShow: function (options){
    
  },
  onReady() {
    // 获取组件
    this.ecComponent = this.selectComponent('#mychart-dom-scatter');
    // console.log(this.ecComponent);
  },
 
});
