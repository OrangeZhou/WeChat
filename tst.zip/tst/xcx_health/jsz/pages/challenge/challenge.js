let app =getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tab_id:0,
    data:'',
    dataList:'',
    cardList:'',
    src:'https://wx1.sinaimg.cn/mw1024/005QJNqdgy1frr3qq0s1vj30im05kdfv.jpg',
    hiddenLoading:false
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that =this;
    wx.request({
      url: app.data.url +'/packlist',
      success:function(res){
        // console.log(res.data)
        that.setData({
          data: res.data,
          dataList:res.data.packs
        })
      }
    })
    wx.request({
      url: app.data.url +'/member_plan',
      header:app.getHeader(),
      success:function(res){
        that.setData({
          cardList:res.data.plans
        })
      }
    })
  },
  acticve:function(e){
    var that=this;
    var id =e.currentTarget.dataset.tab;
    that.setData({
      tab_id:id
    })
  },
  // 路由跳转：月度军令状
  yue:function(e){
    let id =e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '../yue/yue?id='+id,
    })
  },
  //路由跳转：年卡详情
  year_detail:function(e){
    var that =this;
    var id =e.currentTarget.dataset.id;
    wx.navigateTo({
      url: '../year_detail/year_detail?id='+id,
    })
  },
  record:function(e){
    let that =this;
    let id =e.currentTarget.dataset.id
    // console.log(id)
    wx.navigateTo({
      url: '../record/record?id='+id,
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})