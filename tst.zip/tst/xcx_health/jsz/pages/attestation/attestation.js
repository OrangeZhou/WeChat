let app =getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    statu:0,
    key:'',
    name:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  changename:function(e){
    var that =this;
    that.setData({
      name:e.detail.value
    })
  },
  changekey: function (e) {
    var that = this;
    that.setData({
      key: e.detail.value
    })
  },
  submit:function(){
    var that =this;
    wx.request({
      url: app.data.url +'/join_company',
      method:"POST",
      header:app.getHeader(),
      data:{
        name:that.data.name,
        key:that.data.key
      },
      success:function(res){
        if(res.data==1){
          that.setData({
            statu: 1
          })
          setTimeout(function () {
            that.setData({
              statu: 0
            })
            wx.switchTab({
              url: '../my/my',
            })
          }, 1500)
        }
        else if(res.data==2){
          wx.showModal({
            title: '错误',
            content: '没有找到该企业',
            showCancel: false
          })
        }else{
          wx.showModal({
            title: '错误',
            content: '请输入正确的密钥',
            showCancel: false
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})