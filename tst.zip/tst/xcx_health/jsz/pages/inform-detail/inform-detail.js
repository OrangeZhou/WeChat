var app =getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    dataList:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that=this;
    var id =options.id;
    wx.request({
      url: app.data.url +'/active_show/'+id,
      success:function(res){
        var data =res.data.list;
        console.log(data)
        data.active_end = data.active_end.substring(0, 16).replace('-', '.').replace('-', '.');
        data.active_start = data.active_start.substring(0, 16).replace('-', '.').replace('-', '.');
        data.enroll_end = data.enroll_end.substring(0, 16).replace('-', '.').replace('-', '.');
        data.enroll_start = data.enroll_start.substring(0, 16).replace('-', '.').replace('-', '.');
        data.coupon.end_at = data.coupon.end_at.substring(0, 10).replace('-', '.').replace('-', '.');
        data.coupon.start_at = data.coupon.start_at.substring(0, 10).replace('-', '.').replace('-', '.');
          if (data.coupon.ratio.toString().split('.')[1]==0){
            data.coupon.ratio = parseInt(data.coupon.ratio.toString());
          }
        that.setData({
          dataList:data
        })
      }
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})