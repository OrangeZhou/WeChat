let app =getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    num:'1',
    hiddenmodalput: true,
    price:'',
    dataList:'',
    pwd:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    var id =options.id;
    // console.log(id)
    wx.request({
      url: app.data.url +'/buy_good/'+id,
      header:app.getHeader(),
      success:function(res){
        that.setData({
          dataList:res.data.good,
          price:res.data.good.price
        })
      },
    })
  },
  select_coupon: function () {
    var that = this;
    return false;
    var type = that.data.dataList2.oncustomer;
    if (type.length == 0) {
      return false
    }
    wx.navigateTo({
      url: '../coupon/coupon?caozuo=select',
    })
  },
  // 加减
  sub:function(){
    var that =this;
    var num = that.data.num;
    num--;
    if (num==0){
      num=1
    }
    that.setData({
      num: num
    })
  },
  add:function(){
    var that =this;
    var num = that.data.num;
    num++;
    that.setData({
      num: num
    })
  },
  payment: function () {
    var that = this;
    wx.showActionSheet({
      itemList: ['微信支付', '余额支付', '习惯养成金支付'],
      success: function (res) {

        if (res.tapIndex == 1 || res.tapIndex == 2) {
          that.setData({
            hiddenmodalput: false,
            tapIndex: res.tapIndex + 1
          })
        } else {
          wx.request({
            url: app.data.url + '/good_order',
            method: 'POST',
            header: app.getHeader(),
            data: {
              type: 1,
              coupon_id: '',
              good_id: that.data.dataList.id,
              number: that.data.num
            },
            success: function (res) {
              var order = res.data;
              wx.requestPayment({
                'timeStamp': order.timeStamp,
                'nonceStr': order.nonceStr,
                'package': order.package,
                'signType': order.signType,
                'paySign': order.paySign,
                success: function (res) {
                  wx.showToast({
                    title: "购买成功!",
                    duration: 500,
                  });
                  wx.switchTab({
                    url:'../sports/sports'
                  })
                },
                fail: function (res) {
                  wx.showModal({
                    title: '提示',
                    content: '支付失败！',
                    showCancel: false
                  })
                }
              })
            },
          })
        }

      },
      fail: function (res) {
        console.log(res.errMsg)
      }
    })
  },
  //取消按钮  
  cancel: function () {
    this.setData({
      hiddenmodalput: true
    });
  },
  //确认  
  confirm: function () {
    // console.log(222)
    var that = this;
    var pwd = that.data.pwd;
    if (!/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$/.test(pwd)) {
      wx.showModal({
        title: '提示',
        content: '密码不正确，请重新输入！',
        showCancel: false
      })
      return false
    }
    this.setData({
      hiddenmodalput: true
    })
    wx.request({
      url: app.data.url + '/good_order',
      method: "POST",
      header: app.getHeader(),
      data: {
        type: that.data.tapIndex,
        coupon_id: '',
        password: that.data.pwd,
        number:that.data.num,
        good_id:that.data.dataList.id
      },
      success: function (res) {
        if (res.data == 1) {
          wx.showToast({
            title: '支付成功',
          })
          setTimeout(()=>{
            wx.switchTab({
              url: '../my/my',
              success: function (e) {
                var page = getCurrentPages().pop();
                if (page == undefined || page == null) return;
                page.onLoad();
              } 
            })
          },200)
        
        }
        else if (res.data == 10) {
          wx.showModal({
            title: '提示',
            content: '已达限定人数！',
            showCancel: false
          })
        }else{
          wx.showModal({
            title: '提示',
            content: '支付失败！',
            showCancel: false
          })
        }
      },
      fail:function(){
        wx.showModal({
          title: '提示',
          content: '支付失败！',
          showCancel: false
        })
      }
    })
  },
  change: function (e) {
    var that = this;
    var pwd = e.detail.value;
    that.setData({
      pwd: pwd
    })
  },  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})