var app =getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tab_id:0,
    dataList:'',
    price:'',
    hiddenmodalput: true, //可以通过hidden是否掩藏弹出框的属性，来指定那个弹出框
    coupon_type: '',//优惠券类型
    discount: '',//折率
    coupon_id: '',//优惠券id
    pwd: '',//支付密码
    tapIndex: '',//支付方式
    format_id:1, //规格id
    fixfxs_id:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    that.setData({
      fixfxs_id:options.id
    })
    // console.log(app.getHeader())
    wx.request({
      url: app.data.url +'/format',
      header:app.getHeader(),
      success:function(res){
        // console.log(res.data)
        that.setData({
          dataList:res.data.formats,
          price:res.data.formats[0].total_price
        })
      }
    })
  },
  // 点击变色
  active:function(e){
    var that =this;
    var id =e.currentTarget.dataset.tab;
    var data =e.currentTarget.dataset.data;
    var format_id =e.currentTarget.dataset.id
    that.setData({
      tab_id:id,
      price:data.total_price,
      format_id: format_id
    })
  },
  select_coupon: function () {
    var that = this;
    wx.navigateTo({
      url: '../coupon/coupon?caozuo=select2',
    })
  },
  change:function(e){
      var that =this;
      var pwd =e.detail.value;
      that.setData({
        pwd:pwd
      })
  },
  confirm:function(){
    var that =this;
    var pwd =that.data.pwd;
    if (!/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$/.test(pwd)) {
      wx.showModal({
        title: '提示',
        content: '密码不正确，请重新输入！',
        showCancel: false
      })
      return false
    }else{
      wx.request({
        url: app.data.url +'/course_order',
        method:"POST",
        header:app.getHeader(),
        data:{
          format_id: that.data.format_id,
          coupon_id: that.data.coupon_id,
          fixfxs_id: that.data.fixfxs_id,
          password: that.data.pwd,
          type: that.data.tapIndex
        },
        success:function(res){
          // console.log(res.data)
            if(res.data==1){
              wx.showToast({
                title: '购买成功！',
            })
            that.setData({
              hiddenmodalput: true
            })
            setTimeout(function(){
              wx.switchTab({
                url:'../my/my',
                  success: function (e) {
                  var page = getCurrentPages().pop();
                  if (page == undefined || page == null) return;
                  page.onLoad();
                }
              })
            }, 1000)
          }else{
              wx.showModal({
                title: '提示',
                content: '支付失败！',
                showCancel: false
              })
          }
        }
      })
    }
  },
  payment:function(){
    var that =this;
    wx.showActionSheet({
      itemList: ['微信支付', '余额支付', '习惯养成金支付'],
      success:function(res){
        if (res.tapIndex == 1 || res.tapIndex==2){
          that.setData({
            hiddenmodalput: false,
            tapIndex: res.tapIndex+1
          })
        }else{
          wx.request({
            url: app.data.url + '/course_order',
            data: {
              format_id: that.data.format_id,
              coupon_id: that.data.coupon_id,
              fixfxs_id: that.data.fixfxs_id,
              password: that.data.pwd,
              type:1
            },
            method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
            header: app.getHeader(),
            success: function (res) {
              var order = res.data;
              // console.log(order)
              wx.requestPayment({
                'timeStamp': order.timeStamp,
                'nonceStr': order.nonceStr,
                'package': order.package,
                'signType': order.signType,
                'paySign': order.paySign,
                success: function (res) {
                  wx.showToast({
                    title: "购买成功!",
                    duration: 1000,

                  });
                  setTimeout(function () {
                    wx.reLaunch({
                      url: '../my/my',
                    });
                  }, 1000);

                },
                fail: function (res) {
                  // console.log("shibai")
                  // app.toast(res);
                  console.log(res)
                }
              })

            },
            fail: function () {
              // fail
              app.toast('网络异常！err:wxpay');
            }
          })
        }
      }
    })

  },
  cancel:function(){
    var that = this;
    that.setData({
      hiddenmodalput: true
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})