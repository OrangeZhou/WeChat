let app =getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tab_id:3,
    price:[
      { id: 1, num: 0.01 },
      { id: 2, num: 100 },
      { id: 3, num: 990 },
      { id: 4, num: 1000 },
    ],
    yue:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    wx.request({
      url: app.data.url +'/diposit_show',
      header:app.getHeader(),
      success:function(res){
        // console.log(res.data)
          that.setData({
            yue: res.data.card_money
          })
      }
    })
  },
  active:function(e){
    var that =this;
    var id =e.currentTarget.dataset.tab;
    that.setData({
      tab_id:id
    })
  },
  submit:function(){
    var that = this;
    var price =that.data.price[that.data.tab_id-1].num
    wx.request({
      url: app.data.url + '/diposit_order',
      data: {
        price:price
      },
      method: 'POST', // OPTIONS, GET, HEAD, POST, PUT, DELETE, TRACE, CONNECT
      header: app.getHeader(),
      success: function (res) {
        var order = res.data;
        wx.requestPayment({
          'timeStamp': order.timeStamp,
          'nonceStr': order.nonceStr,
          'package': order.package,
          'signType': order.signType,
          'paySign': order.paySign,
          success: function (res) {
            wx.showToast({
              title: "充值成功!",
              duration: 2000,

            });
            setTimeout(function () {
              wx.reLaunch({
                url: '../my/my',
              });
            }, 2500);

          },
          fail: function (res) {
            // console.log("shibai")
            // app.toast(res);
            console.log(res)
          }
        })

      },
      fail: function () {
        // fail
        app.toast('网络异常！err:wxpay');
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})