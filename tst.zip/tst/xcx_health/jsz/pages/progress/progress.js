let app =getApp();
var times=''
Page({

  /**
   * 页面的初始数据
   */
  data: {
    num:0,
    left:-10,
    out:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this
    var num = 0;
    var left = -10;
    if (options) {
      app.data.out=options.out;
      times = setInterval(function () {
        if (num != 100) {
          num = num + 5;
          left = left + 5;
          that.setData({
            num: num,
            left: left
          })
        } else {
          num = 100;
          that.setData({
            num: 100,
          })
          clearInterval(times);
          that.tiao();
          return false
        }
      }, 100);
    }
    
     
  },
 
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
  tiao:function(){
    wx.switchTab({
      url: '../sports/sports',
      success: function (e) {
        var page = getCurrentPages().pop();
        // console.log(page)
        if (page == undefined || page == null) return;
        page.onLoad();
      }
    })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})