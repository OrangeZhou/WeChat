let utils =require('../../utils/util.js');
let app =getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    show:'',
    dataList:'',//总订单数据
    dataList2:'',//门票订单数据
    coupon_type:'',//优惠券类型
    discount:'',//折率
    hiddenmodalput: true, //可以通过hidden是否掩藏弹出框的属性，来指定那个弹出框
    coupon_id:'',//优惠券id
    pwd:'',//支付密码
    tapIndex:'',//支付方式
    now_date:'',
    date:'',
    hidden:true
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let that =this;
    let date2 =new Date();
    that.setData({
      date: utils.formatTime(date2),
      now_date: utils.formatTime(date2),
      hidden: false
    })
    wx.request({
      url: app.data.url +'/is_instore',
      header:app.getHeader(),
      success:function(res){
        if(res.data.type==0){
          wx.request({
            url: app.data.url +'/first_date',
            header:app.getHeader(),
            success:function(res){
              // console.log(res.data)
              that.setData({
                start_date: res.data.substr(0, 10),
              })
              // console.log(that.data.start_date)
              wx.request({
                url: app.data.url + '/choose_date_order',
                header: app.getHeader(),
                method: "POST",
                data: {
                  date: utils.formatTime(date2)
                },
                success: function (res) {
                  // console.log(res.data)
                  for (let i in res.data.order_day) {
                    switch (res.data.order_day[i].pay_way) {
                      case 1:
                        res.data.order_day[i].pay_type = '微信支付';
                        break;
                      case 2:
                        res.data.order_day[i].pay_type = '余额支付';
                        break;
                      case 3:
                        res.data.order_day[i].pay_type = '养成金支付';
                        break;
                      case 4:
                        res.data.order_day[i].pay_type = '公司支付';
                        break;
                    }
                  }
                  that.setData({
                    dataList: res.data,
                    show: false,
                    hidden: true
                  })
                }
              })
            }
          })
        }else{
          wx.request({
            url: app.data.url + '/buy_ticket',
            header: app.getHeader(),
            success: function (res) {
              // console.log(res.data)
              that.setData({
                dataList2: res.data,
                show: true,
              })
            }
          })
          wx.hideNavigationBarLoading()
        }
      },
    })
   
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  select_coupon:function(){
    var that =this;
    var type =that.data.dataList2.oncustomer.coupon;
    // console.log(type)
    if(type.length==0){
      return false
    }else{
      wx.navigateTo({
        url: '../coupon/coupon?caozuo=select',
      })
    }
    
  },
  // list(type){
  //   var list=''
  //   if(type==1){
  //     list = [];
  //   }else{
  //     list = ;
  //   }
  //   return list
  // },
  // 支付方式
  payment: function () {
    var that =this;
    wx.showActionSheet({
      itemList: ['微信支付', '余额支付', '习惯养成金支付', '公司支付'],
      success: function (res) {
        if (res.tapIndex == 1 || res.tapIndex == 2 || res.tapIndex == 3  ){
          that.setData({
            hiddenmodalput:false,
            tapIndex: res.tapIndex+1
          })
        }else{
          wx.request({
            url: app.data.url + '/ticket_order',
            method: 'POST',
            header: app.getHeader(),
            data: {
              type: 1,
              coupon_id: that.data.coupon_id,
              ticket_id: that.data.dataList2.ticket.id,
            },
            success: function (res) {
                  var order = res.data;
                  wx.requestPayment({
                    'timeStamp': order.timeStamp,
                    'nonceStr': order.nonceStr,
                    'package': order.package,
                    'signType': order.signType,
                    'paySign': order.paySign,
                    success: function (res) {
                      wx.request({
                        url: app.data.url +'/openlock',
                        header: app.getHeader(),
                        method: 'GET',
                        success: function(res) {
                          wx.showToast({
                            title: "购买成功!",
                            duration: 500,
                          });
                          
                            wx.redirectTo({
                              url: '../progress/progress?out=jin'
                            })
                          
                        },
                        fail: function(res) {
                          wx.showModal({
                            title: '提示',
                            content: '支付失败！',
                            showCancel:false
                          })
                        },
                        complete: function(res) {},
                      })
                    },
                    fail: function (res) {
                      console.log(res)
                    }
                }) 
            },
          })
        }
       
      },
      fail: function (res) {
        console.log(res.errMsg)
      }
    })
  },
  change:function(e){
    var that =this;
    var pwd =e.detail.value;
    that.setData({
      pwd:pwd
    })
  },
  //点击按钮痰喘指定的hiddenmodalput弹出框  
  modalinput: function () {
    this.setData({
      hiddenmodalput: !this.data.hiddenmodalput
    })
  },
  //取消按钮  
  cancel: function () {
    this.setData({
      hiddenmodalput: true
    });
  },
  //确认  
  confirm: function () {
    // console.log(222)
    var that =this;
    var pwd =that.data.pwd;
    if (!/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$/.test(pwd)) {
      wx.showModal({
        title: '提示',
        content: '密码不正确，请重新输入！',
        showCancel: false
      })
      that.setData({
        pwd:''
      })
      return false
    }
    this.setData({
      hiddenmodalput: true
    })
    wx.request({
      url: app.data.url + '/ticket_order',
      method: "POST",
      header: app.getHeader(),
      data: {
        type: that.data.tapIndex,
        coupon_id: that.data.coupon_id,
        ticket_id: that.data.dataList2.ticket.id,
        password: that.data.pwd
      },
      success:function(res){
          if(res.data==1){
            wx.showNavigationBarLoading()
            wx.request({
              url: app.data.url + '/openlock',
              header: app.getHeader(),
              method: 'POST',
              success: function (res) {
                wx.showToast({
                  title: "购买成功!",
                  duration: 500,
                });
                setTimeout(function () {
                  wx.showNavigationBarLoading()
                  wx.redirectTo({
                    url: '../progress/progress?out=jin'
                  })
                }, 500);
              },
              fail: function (res) { },
              complete: function (res) { },
            })
            
          }
          else if(res.data==10){
            wx.showModal({
              title: '提示',
              content: '已达限定人数！',
              showCancel: false
            })
            that.setData({
              pwd: ''
            })
          }else{
            wx.showModal({
              title: '提示',
              content: '支付失败！',
              showCancel: false
            })
            that.setData({
              pwd: ''
            })
          }
      },
      fail:function(){
        wx.showModal({
          title: '提示',
          content: '支付失败！',
          showCancel: false
        })
        that.setData({
          pwd: ''
        })
      }
    })
  },
  // 用户选择日期  
  bindViewEvent:function(e){
    var that =this;
    var date = e.detail.value
    // console.log(date)
    that.setData({
      now_date: date
    })
    wx.request({
      url: app.data.url + '/choose_date_order',
      header: app.getHeader(),
      method: "POST",
      data: {
        date: date
      },
      success: function (res) {
        // console.log(res.data)
        for (let i in res.data.order_day) {
          switch (res.data.order_day[i].pay_way) {
            case 1:
              res.data.order_day[i].pay_type = '微信支付';
              break;
            case 2:
              res.data.order_day[i].pay_type = '余额支付';
              break;
            case 3:
              res.data.order_day[i].pay_type = '养成金支付';
              break;
            case 4:
              res.data.order_day[i].pay_type = '公司支付';
              break;
          }
        }
        that.setData({
          dataList: res.data
        })
      }
    })
   
  },
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})