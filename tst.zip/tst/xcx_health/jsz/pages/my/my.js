var app =getApp()
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:'',
    userData:'',
    period:'',
    vip_time:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    that.setData({
      userInfo:wx.getStorageSync("userInfo")
    })
    wx.request({
      url: app.data.url +'/user_info',
      header:app.getHeader(),
      success:function(res){
        // console.log(res.data)
        if (res.data.oncustomer.member_end != '' && res.data.oncustomer.member_end !=null){
          res.data.oncustomer.member_end = res.data.oncustomer.member_end.substr(0,10)
        }
        that.setData({
          userData:res.data.oncustomer,
          vip_time: res.data.oncustomer.member_end
        })
        
      }
    })
    wx.request({
      url: app.data.url + '/get_sex',
      method: "GET",
      header: app.getHeader(),
      success: function (res) {
        // console.log(res.data)
        wx.setStorageSync('userphone', res.data.oncustomer.tel);
        that.setData({
          period: res.data.oncustomer.is_member
        })
      }
    })
    wx.setStorageSync('qiye',true)
  },
  my_courses:function(){
    wx.navigateTo({
      url: '../my-courses/my-courses',
    })
  },
  // 路由跳转：电子档案
  record:function(){
    wx.navigateTo({
      url: '../line/index',
    })
  },
  // 路由跳转：企业认证
  attestation:function(){
    wx.navigateTo({
      url: '../attestation/attestation',
    })
  },
  // 路由跳转：充值页面
  recharge:function(){
    wx.navigateTo({
      url: '../recharge/recharge',
    })
  },
  // 路由跳转：优惠券
  coupon:function(){
    wx.navigateTo({
      url: '../coupon/coupon',
    })
  },
  // 路由跳转：修改支付密码
  change:function(){
    wx.navigateTo({
      url: '../change/change',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})