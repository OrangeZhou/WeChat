let app =getApp();
let utils =require('../../utils/util.js');
Page({

  /**
   * 页面的初始数据
   */
  data: {
    
    canCode:true,
    times:60,
    tab: null,
    username:'',
    userphone:'',
    code:'', 
    date: '选择出生日期',
    r_code:'',
    pwd:'',
    r_pwd:'',
    end:''
  },
 
 
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    var date =new Date()
    var end = utils.formatTime(date);
    that.setData({
      openid:options.openid
    })
    that.setData({
      end:end
    })
  },
  sex:function(e){
    var that =this;
    var id =e.currentTarget.dataset.tab;
    that.setData({
      tab:id
    })
  },
  username:function(e){
    var that = this;
    var username = e.detail.value;
    that.setData({
      username: username
    })
  },
  userphone:function(e){
    var that = this;
    var userphone = e.detail.value;
    that.setData({
      userphone: userphone
    })
  },
  bindDateChange:function(e){
    var that =this;
    var date =e.detail.value
    that.setData({
      date:date
    })
  },
  pwd:function(e){
    var that = this;
    var date = e.detail.value
    that.setData({
      pwd: date
    })
  },
  r_pwd: function (e) {
    var that = this;
    var date = e.detail.value
    that.setData({
      r_pwd: date
    })
  },
  getCode:function(){
    var that =this;
    var userphone=that.data.userphone;
    if (!(/^1[34578]\d{9}$/.test(userphone))) {
      wx.showModal({
        title: '提示',
        content: '请输入正确的手机号码！',
      })
      return false
    }
    wx.request({
      url: app.data.url +'/sendSms',
      method:"POST",
      data:{
        number: userphone,
        password: 'zhouleizhoulei'
      },
      success:function(res){
        that.setData({
          r_code:res.data
        })
        wx.setStorageSync('userphone',userphone)
      }
    })
    that.setTimes()
  },
  setTimes:function(){
    var that =this;
    var time =that.data.times;
    time--;
    that.setData({
      times:time,
      canCode:false
    })
    var settimes=setTimeout(that.setTimes,1000)
    if(time<1){
      clearTimeout(settimes)
      that.setData({
        canCode:true,
        times:60
      })
    }
    
  },
  code:function(e){
    var that =this;
    that.setData({
      code:e.detail.value
    })
  },
  // 提交表单
  submit:function(){
    var that = this;
    var username = that.data.username;
    var userphone = that.data.userphone;
    var pwd =that.data.pwd;
    var r_pwd =that.data.r_pwd;
    if (that.data.tab == null || that.data.tab == ''){
      wx.showModal({
        title: '提示',
        content: '请选择您的性别！',
        showCancel: false
      })
      return false
    }
    if (!/^([\u4e00-\u9fa5]){2,7}$/.test(username)) {
      wx.showModal({
        title: '提示',
        content: '请输入正确的姓名！',
        showCancel: false
      })
      return false
    }
    if (that.data.date =="选择出生日期"){
      wx.showModal({
        title: '提示',
        content: '请选择您的出生日期！',
        showCancel: false
      })
      return false
    }
    if (!(/^1[34578]\d{9}$/.test(userphone))) {
      wx.showModal({
        title: '提示',
        content: '请输入正确的手机号码！',
        showCancel: false
      })
      return false
    }

    if(that.data.code!=that.data.r_code ||that.data.code==''){
      wx.showModal({
        title: '提示',
        content: '请输入正确的验证码！',
        showCancel: false
      })
      return false
    }
    if (!/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$/.test(pwd)){
      wx.showModal({
        title: '提示',
        content: '请输入正确格式的密码！',
        showCancel: false
      })
      return false
    }
    if(pwd!=r_pwd){
      wx.showModal({
        title: '提示',
        content: '两次密码输入不一致！',
        showCancel: false
      })
      return false
    }
    wx.request({
      url: app.data.url +'/addinfo',
      method:"POST",
      header:app.getHeader(),
      data:{
        name:username,
        sex:that.data.tab,
        tel:userphone,
        birth:that.data.date,
        write:that.data.code,
        rand:that.data.r_code,
        password:that.data.pwd,
        password_re:that.data.r_pwd
      },
      success:function(res){
        // console.log(that.data.openid)
        // console.log(res.data)
        // console.log(username)
        // console.log(that.data.tab)
        // console.log(userphone)
        // console.log(that.data.code)
        // console.log(that.data.r_code)
        // console.log(that.data.pwd)
        // console.log(that.data.r_pwd)
        console.log(res.data)
        if(res.data==1){
          wx.setStorageSync('xinren', 'ok')
          wx.showToast({
            title: '录入成功',
          })
          setTimeout(function () {
            wx.switchTab({
              url: '../sports/sports'
            })
          }, 500)
        }else{
          wx.showModal({
            title: '录入失败',
            content: '网络异常',
            showCancel:false
          })
          return false
        }
      }
    })
  },
  // 路由跳转：运动页
  sports:function(){
   
    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})