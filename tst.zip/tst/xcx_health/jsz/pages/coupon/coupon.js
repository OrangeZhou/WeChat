var app =getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    dataList:'',
    caozuo:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    if(options.caozuo=='select'){
      wx.request({
        url: app.data.url +'/buy_ticket',
        header: app.getHeader(),
        success:function(res){
          var data = res.data.oncustomer.coupon;
          // console.log(data);
          for (let i in data) {
            data[i].end_at = data[i].end_at.substring(0, 10).replace('-', '.').replace('-', '.');
            data[i].start_at = data[i].start_at.substring(0, 10).replace('-', '.').replace('-', '.');
            data[i].name = [];
            data[i].type = '';
            if (data[i].ratio.toString().split('.')[1] == 0) {
              data[i].ratio = parseInt(data[i].ratio.toString());
            }
            for (let j in data[i].types) {
              data[i].name.push(data[i].types[j].name)
            }
            for (let y in data[i].name) {
              data[i].type += data[i].name[y] + '/';
            }
            data[i].type = data[i].type.substring(0, data[i].type.length - 1)
          }
          that.setData({
            dataList: data,
            caozuo: options.caozuo
          })
        },
      })
    }
    else if (options.caozuo == 'select2'){
      wx.request({
        url: app.data.url+'/format',
        header:app.getHeader(),
        success:function(res){
          var data =res.data.coupons;
          // console.log(data)
          for (let i in data) {
            data[i].end_at = data[i].end_at.substring(0, 10).replace('-', '.').replace('-', '.');
            data[i].start_at = data[i].start_at.substring(0, 10).replace('-', '.').replace('-', '.');
            data[i].name = [];
            data[i].type = '';
            if (data[i].ratio.toString().split('.')[1] == 0) {
              data[i].ratio = parseInt(data[i].ratio.toString());
            }
            for (let j in data[i].types) {
              data[i].name.push(data[i].types[j].name)
            }
            for (let y in data[i].name) {
              data[i].type += data[i].name[y] + '/';
            }
            data[i].type = data[i].type.substring(0, data[i].type.length - 1)
          }
         
          that.setData({
            dataList: data,
            caozuo: options.caozuo
          })
        }
      })
    }else{
      wx.request({
        url: app.data.url + '/user_coupons',
        header:app.getHeader(),
        success: function (res) {
          var data = res.data.coupons
          // console.log(res.data)
          for (let i in data) {
            data[i].end_at = data[i].end_at.substring(0, 10).replace('-', '.').replace('-', '.');
            data[i].start_at = data[i].start_at.substring(0, 10).replace('-', '.').replace('-', '.');
            data[i].name = [];
            data[i].type ='';
            if (data[i].ratio.toString().split('.')[1] == 0) {
              data[i].ratio = parseInt(data[i].ratio.toString());
            }
            for(let j in data[i].types){
              data[i].name.push(data[i].types[j].name)
            }
            for(let y in data[i].name){
              data[i].type+=data[i].name[y]+'/';
            }
            data[i].type = data[i].type.substring(0, data[i].type.length-1)
          }
          // console.log(data)
          that.setData({
            dataList: data
          })
        }
      })
    }
    
  },
  select:function(e){
    var that = this;
    if(that.data.caozuo){
      var data = e.currentTarget.dataset.data;
      var types = data.types;
      var type = '';
      for (let i in types) {
        type += types[i].name + '/';
      }
      // console.log(data)
      var pages = getCurrentPages();
      var currPage = pages[pages.length - 1];   //当前页面
      var prevPage = pages[pages.length - 2];  //上一个页面
      prevPage.setData({
        coupon_type: type.substring(0, type.length - 1),//优惠券类型
        discount: data.ratio,//折率
        coupon_id:data.id
      })
      wx.navigateBack({
        delta: 1
      })
    }
    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})