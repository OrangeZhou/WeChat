
let app =getApp();
var time = '';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tab_id:0,
    dataList:'',
    data:'',
    data_record:'',
    date:'',//上课时间
    start_date:'',
    end_state:'',
    state:true,
    courses_id:'',
    min: "00",
    s: "00",
    types:'',
    times:'',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    let id =options.id;
    var that =this;
    wx.request({
      url: app.data.url +'/course_show/'+id,
      header:app.getHeader(),
      success:function(res){
        // console.log(res.data)
        that.setData({
          dataList:res.data.course,
          data:res.data,
          courses_id:id
        })
      }
    })
    wx.request({
      url: app.data.url +'/course_record/'+id,
      header: app.getHeader(),
      success:function(res){
        that.setData({
          data_record:res.data
        })
      }
    })
    wx.request({
      url: app.data.url +'/is_studying',
      method:'POST',
      header:app.getHeader(),
      data:{
        sjorder_id: id
      },
      success:function(res){
        
        if(res.data==0){
          that.setData({
            types:1,
          })
        }else{
          if(res.data.fen.toString().length==1){
            res.data.fen = '0' + res.data.fen;
          }
          if (res.data.miao.toString().length == 1) {
            res.data.miao = '0' + res.data.miao
          }
          that.setData({
            types: 2,
            min:res.data.fen,
            s:res.data.miao
          })
          that.getTimes('jixu')
        }
      },
    })
  },
  active:function(e){
    var that =this;
    var id =e.currentTarget.dataset.tab;
    that.setData({
      tab_id:id
    })
  },
  attend:function(e){
    var that =this;
    wx.request({
      url: app.data.url +'/get_course_record',
      header:app.getHeader(),
      method:"POST",
      data:{
        sjorder_id: that.data.courses_id,
        type:that.data.types
      },
      success:function(res){
        // console.log(res.data)
        if(res.data==1){
          that.setData({
            state: false,
            types:2
          })
          wx.showToast({
            title: '开始上课',
          })
          that.getTimes('')
        } else if (res.data == 3){
          
        }
        else{
          res.data.record.out_at.date = res.data.record.out_at.date.substr(0,19);
          wx.showToast({
            title: '结束上课',
          })
          that.setData({
            state: true,
            types: 1,
            times:res.data.record,
            min:"00",
            s:"00",
          })
          that.getTimes('close');
        }
      }
    })
    
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  
  getTimes(state){
      var that =this;
      if(that.data.todo<=0){
        wx.showModal({
          title: '提示',
          content: '已无可上课程！',
          showCancel:false
        })
        return false
      }
      var min ='';
      var s='';
      if(state==''){
        time=setInterval(function(){
          s++;
          min=0;
          if (s == 60) {
            s = 0
            min++
          }
          if (s.toString().length == 1) {
            s = "0" + s
          }
          if (min.toString().length == 1) {
            min = "0" + min
          }
          that.setData({
            min: min,
            s: s
          })
        },1000)
      }
      if(state=='jixu'){
        time = setInterval(function () {
          s=that.data.s;
          min = that.data.min;
          s++;
          if (s == 60) {
            s = 0
            min++
          }
          if (s.toString().length == 1) {
            s = "0" + s
          }
          if (min.toString().length == 1) {
            min = "0" + min
          }
          that.setData({
            min: min,
            s: s
          })
        }, 1000)
      }
       if(state=='close'){
        clearInterval(time);
        that.setData({
          min:'00',
          s:'00'
        })
       
      }
  },
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})