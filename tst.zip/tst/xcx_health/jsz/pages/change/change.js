let app =getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userphone:'',
    canCode: true,
    times: 60,
    code:'',
    r_code:'',
    pwd:'',
    r_pwd:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    that.setData({
      userphone:wx.getStorageSync('userphone')
    })
  },
  getCode: function () {
    var that = this;
    wx.request({
      url: app.data.url + '/sendSms',
      method: "POST",
      header:app.getHeader(),
      data: {
        number: that.data.userphone,
        password: 'zhouleizhoulei'
      },
      success: function (res) {
        that.setData({
          r_code: res.data
        })
      }
    })
    that.setTimes()
  },
  setTimes: function () {
    var that = this;
    var time = that.data.times;
    time--;
    that.setData({
      times: time,
      canCode: false
    })
    var settimes = setTimeout(that.setTimes, 1000)
    if (time < 1) {
      clearTimeout(settimes)
      that.setData({
        canCode: true,
        times:60
      })
    }
  },
  code:function(e){
    var that =this;
    that.setData({
      code:e.detail.value
    })
  },
  pwd: function (e) {
    var that = this;
    var date = e.detail.value
    that.setData({
      pwd: date
    })
  },
  r_pwd: function (e) {
    var that = this;
    var date = e.detail.value
    that.setData({
      r_pwd: date
    })
  },
  submit:function(){
    var that =this;
    var pwd =that.data.pwd;
    var r_pwd =that.data.r_pwd;
    var code= that.data.code;
    if (!/^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$/.test(pwd)) {
      wx.showModal({
        title: '提示',
        content: '请输入正确格式的密码！',
        showCancel: false
      })
      return false
    }
    if (pwd != r_pwd) {
      wx.showModal({
        title: '提示',
        content: '两次面输入不一致！',
        showCancel: false
      })
      return false
    }
    if (that.data.code != that.data.r_code || that.data.code == '') {
      wx.showModal({
        title: '提示',
        content: '请输入正确的验证码！',
        showCancel: false
      })
      return false
    }
    wx.request({
      url: app.data.url +'/update_password',
      method:"POST",
      header:app.getHeader(),
      data:{
        write:that.data.code,
        rand:that.data.r_code,
        password:that.data.pwd,
        password_re:that.data.r_pwd
      },
      success:function(res){
        if(res.data==1){
          wx.showToast({
            title: '修改成功',
          })
          setTimeout(()=>{
            wx.switchTab({
              url: '../my/my'
            })
          },800)
          
        }else{
          wx.showModal({
            title: '失败',
            content: '网络异常！',
            showCancel: false
          })
        }
      }
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})