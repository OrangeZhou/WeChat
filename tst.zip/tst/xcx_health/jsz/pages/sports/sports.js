var app =getApp()
var t='';
var time ='';
var cxt_arc=''
Page({

  /**
   * 页面的初始数据
   */
  data: {
    code:true,//"true"显示扫码前的页面，反之则显示扫码后的页面
    num:0,
    ts1:true,//活跃天数提示框
    ts2:true,//有效打卡提示框
    width:0,//计时画布宽度
    height:0,
    bol:false, //显示蒙版
    bol_5:'',//显示新人专享5折优惠券弹框
    index_no:'',//扫码前的页面数据
    qiye:'',
    saoma: '',
    guihuan:'',
    ling:'',
    mon:'',
    loadingHidden:true,
    //企业用户来认证
    items: [
      { name: 'key', value: '' },
      { name: 'towel', value: '', checked: 'true' },
      { name: 'slipper', value: '' },
    ],
    key:false,
    towel:false,
    slipper:false,
    min:"00",
    s:"00"
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    var num = '';
    if (wx.getStorageSync('xinren') == 'ok') {
      that.setData({
        bol: true,
        bol_5: 101,
      })
      
    } 
    if (app.data.out == 'chu') {
      that.setData({
        bol: true,
        ling: 'chu'
      })
    }
    else if (app.data.out == 'jin') {
      that.setData({
        bol: true,
        ling: 'jin'
      })
    }
    if (wx.getStorageSync('saoma')){
      that.setData({
          saoma:true
      })
    }else{
      that.setData({
          saoma: false
      })
    }
    if (wx.getStorageSync('qiye')){
      that.setData({
        qiye:true
      })
    }else{
      that.setData({
        qiye: false
      })
    }
    wx.request({
      url: app.data.url+'/get_sex',
      method:"GET",
      header:app.getHeader(),
      success:function(res){
        // console.log(res.data.oncustomer)
        that.setData({
          sex:res.data.oncustomer.sex
        })
      }
    })
    wx.request({
      url:app.data.url+'/is_instore',
      method:"GET",
      header:app.getHeader(),
      success:function(res){
        // console.log(res.data.type)
          if(res.data.type==0){
            that.setData({
              code:false,
              min:res.data.fen,
              s:res.data.miao,
            })
            that.times();
              wx.getSystemInfo({
                success: function (res) {
                  that.data.width = res.windowWidth
                  that.data.height = res.windowHeight
                }
              })
              var width = (that.data.width / 750) * 600;
              var height = (that.data.width / 750) * 600;
               t =setInterval(function () {
                 num = parseInt(that.data.min * 60) + parseInt(that.data.s);
                if (num == 43200) {
                  return false
                }
                num++
                cxt_arc = wx.createCanvasContext('canvasArc');//创建并返回绘图上下文context对象。  
                cxt_arc.setStrokeStyle('#F4F4F4');
                cxt_arc.setLineCap('round')
                cxt_arc.translate(width / 2, height / 2);
                cxt_arc.setLineWidth(1);
                cxt_arc.rotate(-Math.PI / 2);//时间从3点开始，倒转90度 
                for (var i = 0; i < 60; i++) {
                  cxt_arc.beginPath();
                  cxt_arc.rotate(Math.PI / 30);
                  cxt_arc.moveTo(width / 2 - 5, 0);
                  cxt_arc.lineTo(width / 2 - 15, 0);
                  cxt_arc.stroke();
                }
                // context.draw()
                cxt_arc.setLineWidth(10);
                cxt_arc.setStrokeStyle('#F5F5F5');
                cxt_arc.setLineCap('round');
                cxt_arc.beginPath();//开始一个新的路径  
                cxt_arc.arc(0, 0, width / 2 - 30, 0, 2 * Math.PI, false);//设置一个原点(106,106)，半径为100的圆的路径到当前路径  
                cxt_arc.stroke();//对当前路径进行描边  

                cxt_arc.setLineWidth(10);
                cxt_arc.setStrokeStyle('#F26640');
                cxt_arc.setLineCap('round');
                cxt_arc.beginPath();//开始一个新的路径  
                cxt_arc.arc(0, 0, width / 2 - 30, 0, Math.PI / 180 * num / 216, false);
                cxt_arc.stroke();//对当前路径进行描边  
                cxt_arc.draw();
                that.setData({
                  num: num
                })
              }, 100)
  
          }else{
            if(t){
              clearInterval(t)
            }
            
            wx.request({
              url: app.data.url + '/index_no',
              header: app.getHeader(),
              method: 'GET',
              success: function (res) {
                // console.log(res.data)
                var data =res.data.date;
                // console.log(data2)
                for (let i in data) {
                  // console.log(res.data.date[i].date);
                  data[i].mon = data[i].date.toString().substring(0, 10);
                  data[i].date = data[i].date.toString().substring(8, 10);  
                }
                for(let j in res.data.selected_days){
                  res.data.selected_days[j] = res.data.selected_days[j].toString().substring(8, 10);
                }
                for (let i in data){
                  if (res.data.selected_days.indexOf(data[i].date) != -1) {
                    data[i].type = 1
                  }
                }
                var year = res.data.date[7].mon.substr(0, 4)
                var mon = res.data.date[7].mon.substring(5,7)
                that.setData({
                  code: true,
                  index_no: res.data,
                  year:year,
                  mon:mon
                })
                // console.log(res.data)
              },
              fail: function (res) { },
              complete: function (res) { },
            })
          }
      }
    })
  },
  ts1:function(e){
    let that =this;
    var bol =that.data.ts1;
    bol=!bol;
    that.setData({
      ts1:bol
    })
  },
  ts2: function (e) {
    let that = this;
    var bol = that.data.ts2;
    // console.log(bol)
    bol = !bol;
    that.setData({
      ts2: bol
    })
  },
  // 关闭弹窗
  close:function(res){
    // console.log(res)
    var that =this;
    wx.removeStorageSync('xinren');
    that.setData({
      bol:false,
      bol_5:''
    })
  },
  // 调用摄像头
  getLocalImage:function(){
    var that =this;
    wx.setStorageSync('saoma', true)
    wx.scanCode({
      success:(res)=>{
        if (res.result.substr(0, 1) == that.data.sex) {
          wx.request({
            url: app.data.url +'/is_member',
            header:app.getHeader(),
            success:function(res){
              that.setData({
                loadingHidden:false
              })
              if(res.data==1){
                wx.request({
                  url: app.data.url + '/openlock',
                  header: app.getHeader(),
                  method: 'GET',
                  success: function (res) {
                    setTimeout(() => {
                      that.setData({
                        loadingHidden: true
                      })
                      wx.redirectTo({
                        url: '../progress/progress?out=jin',
                      })
                    }, 500)
                  },
                })              
              }else{
                that.setData({
                  loadingHidden: true
                })
                wx.navigateTo({
                  url: '../order/order'
                })
              }
            }
          })
          
        }
        else if(res.result=='out'){
          wx.showNavigationBarLoading()
          wx.request({
            url: app.data.url +'/get_outinfo',
            method:'POST',
            header:app.getHeader(),
            data:{
              type:1
            },
            success:function(res){
                if(res.data==1){
                  wx.request({
                    url: app.data.url + '/openlock',
                    header: app.getHeader(),
                    method: 'GET',
                    success: function (res) {
                      wx.hideNavigationBarLoading()
                      wx.redirectTo({
                        url: '../progress/progress?out=chu',
                      })
                  },
                })
              }
            }
          })
        }else if(res.result.substr(0,4)=='good'){
          wx.navigateTo({
            url: '../shopping/shopping?id=' + res.result.substr(5),
          })
        }else{
          wx.showModal({
            title: '提示',
            content: '性别诡异，扫码请去隔壁',
            showCancel:false
          })
        }
      }
    })
  },
  
  // 复选框
  checkboxChange1:function(e){
    var that =this;
    var key =that.data.key
    that.setData({
      key:!key
    })

  },
  checkboxChange2: function (e) {
    var that = this;
    var towel = that.data.towel
    that.setData({
      towel: !towel
    })

  },
  checkboxChange3: function (e) {
    var that = this;
    var slipper = that.data.slipper
    that.setData({
      slipper: !slipper
    })

  },
  // 判断是否全部勾选
  r_close:function(){
    var that =this;
    if(that.data.key==true&&that.data.towel==true&&that.data.slipper==true){
      that.close('null')
    }else{
      wx.showModal({
        title: '提示',
        content: '您还有没归还的物品吗？',
      })
    }
  },
  //路由跳转：教练页
  coach:function(){
    wx.navigateTo({
      url: '../coach/coach',
    })
  },
  //路由跳转：通知页
  tzb:function(){
    wx.navigateTo({
      url: '../inform/inform',
    })
  },
  // 路由跳转：站点页
  inform:function(){
    wx.navigateTo({
      url: '../site/site',
    })
  },
  // 路由跳转：订单页
  order:function(){
    wx.navigateTo({
      url: '../order/order',
    })
    // console.log(555)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    // 页面渲染完成  
    var that = this;
    
    
  },
  /**
   * 生命周期函数--监听页面显示
   */
  // 计时
  times:function(){
    var min = 0;
    var s = 0
    var that = this;
    if(that.data.code==false){
      min=that.data.min;
      s=that.data.s
    }
    function run() {
      s++;
      if (s == 60) {
        s = 0
        min++
      }
      if (s.toString().length == 1) {
        s = "0" + s
      }
      if (min.toString().length == 1) {
        min = "0" + min
      }
      that.setData({
        min: min,
        s: s
      })
    }
     time = setInterval(run, 1000)
  },
  scatter:function(e){
    var mon =e.currentTarget.dataset.mon
    wx.navigateTo({
      url: '../scatter/index?mon='+mon,
      
    })
  },
  onShow: function () {
   
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function (res) {
    return {
      title: '质能健身站',
      path: '/pages/welcome/welcome',
      success: function (res) {
      },
      fail: function (err) {
        console.log(err)
      }
    }
  },
})