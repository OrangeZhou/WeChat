let app =getApp();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    tab_id:0,
    state:{
      src:'',
      text:'',
      dataList:''
    }
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    var state =options.state;
    var id =options.id;
    var pack_id =options.pack_id
    // console.log(pack_id)
    // console.log(id)
    switch(state){
      case '1':
      that.setData({
        src:'../../images/tzb.png',
        text:'挑战成功'
      })
      break;
      case '0':
      that.setData({
        src: '../../images/fail.jpg',
        text: '挑战失败'
      })
      break;
      default:
        that.setData({
          src: '../../images/tzb.png',
          text: '正在参加'
        })
    }
    wx.request({
      url: app.data.url +'/pack_record',
      method:"POST",
      data:{
        pack_id:pack_id,
        id:id
      },
      success:function(res){
        console.log(res.data)
          that.setData({
            pack_orders:res.data.pack_orders,
            pack_records:res.data.pack_records
          })
      }
    })
  },
  active:function(e){
    var that =this;
    var id =e.currentTarget.dataset.tab;
    that.setData({
      tab_id:id
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})