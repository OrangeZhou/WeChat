//app.js hello
App({
  data:{
    userInfo:[],
    url:"https://www.mf.seleted.cn/api",
    openid:'',
    out:''
  },
  onLaunch: function () {
    var that =this;
    // 展示本地存储能力
    var logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    // wx.login({
    //   success: res => {
    //     // 发送 res.code 到后台换取 openId, sessionKey, unionId
    //     // console.log(res.code)
    //     wx.setStorageSync("code",res.code)
    //   }
    // })
    // 获取用户信息
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          wx.login({
            success:res =>{
              // console.log(res.code)
            }
          })
        }
      }
    })
  },
  getHeader: function () {
    var that = this;
    var openid = wx.getStorageSync('openid');//本地取存储的sessionID
    if (openid != "" && openid != null) {
      openid =that.data.openid
      var header = { 'content-type': 'application/x-www-form-urlencoded', 'openid': openid}
    } else {
      var header = { 'content-type': 'application/x-www-form-urlencoded', 'openid': openid}
    }
    return header;
  },
  globalData: {
    userInfo: null
  },
  database: [50, 60, 55, 55, 58]
})