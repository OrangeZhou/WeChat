const QQMapWX =require('../../utils/qqmap-wx-jssdk.js');
var time ='';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    current:1,
    more:true,
    address:'',//地理位置
    tempFilePaths:'',//名片照片
    visualPaths:'',//形象照
    companyPaths:'',//公司logo
    iscode:true,
    num:'',
    name:'',//姓名
    phone:'',//手机号码
    code:'',//验证码
    duty:'',//职务
    duty_ab:'',//职务缩写
    company:'',//公司名称
    url:'',//公司网址
    email:'',//邮箱
    weixin:''//微信
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this
    
  },
  // 点击加边框
  active:function(e){
    var that =this;
    var current=e.currentTarget.dataset.id;
    that.setData({
      current: current
    })
  },
  // 拍摄名片
  chooseimage:function(e){
    var that = this;
    var current = e.currentTarget.dataset.id;
    wx.chooseImage({
      count: 1, // 默认9  
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有  
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片    
        console.log(res)
        that.setData({
          tempFilePaths: res.tempFilePaths[0],
          current: current
        })
      }
    })
  },
  // 发送验证码
  getcode:function(){
    var that =this;
    var num =60;
    time =setInterval(function(){
      num--;
      that.setData({
        num:num,
        iscode:false
      })
      if(num==0){
        clearInterval(time)
        that.setData({
          iscode:true
        })
      }
    },1000)
  },
  // 展开更多信息
  more:function(){
    var that =this;
    var more =that.data.more;
    that.setData({
      more:!more
    })
  },
  // 上传形象照
  visual:function(){
    var that = this;
    wx.chooseImage({
      count: 1, // 默认9  
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有  
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片    
        console.log(res)
        that.setData({
          visualPaths: res.tempFilePaths[0],
        })
      }
    })
  },
  up_company:function(){
    var that = this;
    wx.chooseImage({
      count: 1, // 默认9  
      sizeType: ['original', 'compressed'], // 可以指定是原图还是压缩图，默认二者都有  
      sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有  
      success: function (res) {
        // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片    
        console.log(res)
        that.setData({
          companyPaths: res.tempFilePaths[0],
        })
      }
    })
  },
  // 获取地理位置
  getLocation:function(){
    var that =this;
    // 实例化腾讯地图API核心类
    var qqmapsdk = new QQMapWX({
      key: '2CXBZ-JLOCJ-TCMF3-K34DA-XFCMT-G3BF7' // 必填
    });
    //1、获取当前位置坐标
    wx.getLocation({
      type: 'wgs84',
      success: function (res) {
        //2、根据坐标获取当前位置名称，显示在顶部:腾讯地图逆地址解析
        qqmapsdk.reverseGeocoder({
          location: {
            latitude: res.latitude,
            longitude: res.longitude
          },
          success: function (addressRes) {
            var address = addressRes.result.address;
            that.setData({
              address:address
            })
          }
        })
      },
    })
  },
  // 表单
  name:function(e){
    this.setData({
      name:e.detail.value
    })
  },
  phone: function (e) {
    this.setData({
      phone: e.detail.value
    })
  },
  name: function (e) {
    this.setData({
      name: e.detail.value
    })
  },
  duty:function(e){
    this.setData({
      duty: e.detail.value
    })
  },
  duty_ab:function(e){
    this.setData({
      duty_ab: e.detail.value
    })
  },
  company: function (e) {
    this.setData({
      company: e.detail.value
    })
  },
  url: function (e) {
    this.setData({
      url: e.detail.value
    })
  },
  email: function (e) {
    this.setData({
      email: e.detail.value
    })
  },
  weixin: function (e) {
    this.setData({
      weixin: e.detail.value
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})