Page({

  /**
   * 页面的初始数据
   */
  data: {
    letter: ["A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z" ],
    cardListId:''
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    wx.getSystemInfo({
      success: function (res) {
        that.setData({
          screenHeight: res.windowHeight,
        });
      }
    });
    var query = wx.createSelectorQuery();
    //选择id
    query.select('.create').boundingClientRect();
    query.select('.card_list').boundingClientRect()
    query.exec(function (res) {
      console.log(res)
      that.setData({
        height: that.data.screenHeight - res[0].height-55
      })
      //res就是 所有标签为msg_text的元素的信息 的数组
     
      //取高度

      })
  }  ,
  index:function(e){
    var that =this;
    var id =e.currentTarget.dataset.id;
    that.setData({
      cardListId:id
    })
    wx.showToast({
      title: id,
      icon:"none",
      duration: 500
    })
  },
  // 路由跳转：创建名片
  create:function(){
    wx.navigateTo({
      url: '../create/create',
    })
  },
  search:function(){
    wx.navigateTo({
      url: '../search/search',
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})