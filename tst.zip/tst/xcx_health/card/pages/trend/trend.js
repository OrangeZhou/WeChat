Page({

  /**
   * 页面的初始数据
   */
  data: {
    pl_show:'',
    height:'',
    height2:'',
    all:'全文',
    all2:'全文',
    r_height:'',
    r_height2:'',
    overflow:'',
    overflow2: '',
    text:'今天吃了五桶饭，半饱了。今天吃了五桶饭，半饱了。今天吃了五桶饭，半饱了。今天吃了五桶饭，半饱了。今天吃了五桶饭，半饱了。今天吃了五桶饭，半饱了。今天吃了五桶饭，半饱了。今天吃了五桶饭，半饱了。',
    imgArr:[
      "https://wx1.sinaimg.cn/mw690/005QJNqdgy1fs1b2bmas0j304g04gq3w.jpg",
      "https://wx4.sinaimg.cn/mw690/005QJNqdgy1fs1b2bmk0cj304g04gmy4.jpg",
      "https://wx3.sinaimg.cn/mw690/005QJNqdgy1fs1b2c7ncnj304g04fjs7.jpg",
      "https://wx2.sinaimg.cn/mw690/005QJNqdgy1fs1b2bn6goj304g04fdgm.jpg",
      "https://wx3.sinaimg.cn/mw690/005QJNqdgy1fs1b2c7ncnj304g04fjs7.jpg",
      "https://wx1.sinaimg.cn/mw690/005QJNqdgy1fs1b2bmas0j304g04gq3w.jpg"
    ],
    pl_value:'',
    pl_input:false,
    feiji:false,
    meng:false
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that =this;
    //创建节点选择器
    var query = wx.createSelectorQuery();
    var query2 = wx.createSelectorQuery();
    //选择id
    query.select('.msg_text').boundingClientRect()
    query.exec(function (res) {
      //res就是 所有标签为msg_text的元素的信息 的数组
      console.log(res);
      //取高度
      that.setData({
        r_height:res[0].height
      })
      if (res[0].height>80){
        that.setData({
          height: "80px",
          overflow:'hidden'
        })
      }
    })

  },
  // 点击弹出评论和赞的菜单
  show:function(e){
    let that =this;
    let pl_show = that.data.pl_show;
    let id =e.currentTarget.dataset.id
    if (that.data.pl_show==id){
      that.setData({
        pl_show:'',
        pl_input:false
      })
    }else{
      that.setData({
        pl_show: id,
      })
    }
  },
  show_text:function(){
    this.setData({
      meng:true
    })
  },
  meng:function(){
    this.setData({
      meng: false
    })
  },
  // 全文
  all:function(){
    let that =this;
    if(that.data.height=="160rpx"){
      that.setData({
        height:'auto',
        all:"收起",
        overflow: 'visible'
      })
    }else{
      that.setData({
        height: '160rpx',
        all: "全文",
        overflow:'hidden'
      })
    }
  },
  all2: function () {
    let that = this;
    if (that.data.height2 == "160rpx") {
      that.setData({
        height2: 'auto',
        all2: "收起",
        overflow2: 'visible'
      })
    } else {
      that.setData({
        height2: '160rpx',
        all2: "全文",
        overflow2: 'hidden'
      })
    }
  },
  // 点击空白影藏菜单
  blank:function(){
    var that =this;
    that.setData({
      pl_show:'',

    })
  },
  // 预览图片
  previewImg:function(e){
    var that =this;
    console.log(e.currentTarget.dataset.index);
    var index = e.currentTarget.dataset.index;
    var imgArr = that.data.imgArr;
    wx.previewImage({
      current: imgArr[index],     //当前图片地址
      urls: imgArr,               //所有要预览的图片的地址集合 数组形式
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  // 评论
  pl:function(){
    var that =this;
    that.setData({
      pl_input:true
    })
  },
  // 获取评论内容
  pl_input:function(e){
      var that =this;
      var value =e.detail.value;
      that.setData({
        pl_value: value
      })
  },
  // 发送
  send:function(){
    var that =this;
    if (that.data.pl_value==''){
      return false
    }else{
      wx.showToast({
        title: '发送成功！',
      })
      that.setData({
        pl_input:false
      })
    }
  },
  // 发朋友圈
  dynamic:function(){
    wx.navigateTo({
      url: '../dynamic/dynamic',
    })
  },
  // 拖动事件
  ballMoveEvent: function (e) {
    console.log('我被拖动了....')
    var touchs = e.touches[0];
    var pageX = touchs.pageX;
    var pageY = touchs.pageY;
    console.log('pageX: ' + pageX)
    console.log('pageY: ' + pageY)
    //防止坐标越界,view宽高的一般  
    if (pageX < 25) return;
    if (pageX > this.data.screenWidth - 25) return;
    if (this.data.screenHeight - pageY <= 25) return;
    if (pageY <= 25) return;
    //这里用right和bottom.所以需要将pageX pageY转换  
    var x = this.data.screenWidth - pageX - 25;
    var y = this.data.screenHeight - pageY - 25;
    console.log('x: ' + x)
    console.log('y: ' + y)
    this.setData({
      ballBottom: y,
      ballRight: x
    });
  },  
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  },
  // 监听页面滚动
  onPageScroll:function(){
    var that=this;
    
  },
})