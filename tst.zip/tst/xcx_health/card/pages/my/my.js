Page({

  /**
   * 页面的初始数据
   */
  data: {
    zan:'../../images/icons/praise.png',
    zan_active:'../../images/icons/praise_active.png',
    shou:'../../images/icons/collect.png',
    shou_active:'../../images/icons/collect_active.png'
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },
  // 路由跳转：互动分析
  analyze:function(){
    wx.navigateTo({
      url: '../analyze/analyze',
    })
  },
  vip:function(){
    wx.navigateTo({
      url: '../vip/vip',
    })
  },
  invite:function(){
    wx.navigateTo({
      url: '../invite/invite',
    })
  },
  about:function(){
    wx.navigateTo({
      url: '../about/about',
    })
  },
  zan:function(){
    var that =this;
    that.setData({
      zan:'../../images/icons/praise_active.png'
    })
  },
  shou:function(){
    var that = this;
    that.setData({
      shou: '../../images/icons/collect_active.png'
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})