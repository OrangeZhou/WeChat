// pages/about/about.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    x: 260,
    y: 300
  },
  openmap() {
    wx.openLocation({
      latitude: 30.4779600000,
      longitude: 114.4220000000,
      address: '武汉市洪山区高新二路79号唐山商会23楼2306',
      name: '武汉恒鑫创赢科技有限公司',
    })
  },
  call() {
    wx.makePhoneCall({
      phoneNumber: '4000835515'
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
  
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
  
  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
  
  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
  
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
  
  }
})